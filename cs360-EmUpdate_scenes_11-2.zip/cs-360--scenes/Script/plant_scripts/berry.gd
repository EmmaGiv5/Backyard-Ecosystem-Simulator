extends Plant

func update_plant_animation() -> void:
	match life_state:
		LifeState.small:
			$AnimatedSprite2D.play("small")

		LifeState.medium:
			$AnimatedSprite2D.play("medium")

		LifeState.grown:
			$AnimatedSprite2D.play("grown")

		LifeState.wilted:
			$AnimatedSprite2D.play("wilted")
