extends Node

class_name Plant

# --------------------------------
# Vars
# --------------------------------

# life states
enum LifeState { small, medium, grown, wilted }
var life_state: LifeState = LifeState.small

# plant stats
var health: float = 100.0
var water: float = 100.0
var sunlight: float = 100.0

# growth vars 
var growth_threshold: float = 100.0  # growth for for next stage
var growth_progress: float = 0.0     # progress towards next stage
var growth_rate: float = 1.0         # rate the plant grows

# --------------------------------
# Phases
# 	healthy <--> wilted --> dead 
# --------------------------------

# plant moves forward in the phases 
func grow() -> void:
	# will not grow if wilted
	if life_state == LifeState.wilted:
		return
	
	# check if life state is small or medium 
	# inc to next one
	match life_state:
		LifeState.small:
			life_state = LifeState.medium
		LifeState.medium:
			life_state = LifeState.grown

	update_plant_animation()

# plant moves back in the phases 
func wilt() -> void:
	life_state = LifeState.wilted
	update_plant_animation()

func update_growth(delta: float) -> void:
	# check plant health first
	# (later this will factor in)
	plant_health()

	if life_state == LifeState.wilted:
		return

	# Increase growth over time
	growth_progress += growth_rate * delta

	# Check if plant is ready to grow
	if growth_progress >= growth_threshold:
		grow()
		growth_progress = 0.0


# --------------------------------
# Animation
# --------------------------------

# override later for specific plants
func update_plant_animation() -> void:
	pass


# --------------------------------
# Calculations
# --------------------------------

# calculates the overall plant health 
# calc more later
func plant_health() -> void:
	if water <= 0 or sunlight <= 0:
		wilt()

# calcs sun level for plant's placement
# override later
func sun_level() -> void:
	pass

# calcs water level for plant's placement
# override later
func water_level() -> void:
	pass
