extends Node2D

# -----------------------------------
# Vars
# -----------------------------------

# load global plant nodes
var berry_scene = preload("res://Scenes/objects/berry.tscn")
var carrot_scene = preload("res://Scenes/objects/carrot.tscn")
var flower_scene = preload("res://Scenes/objects/flower.tscn")
var grass_scene = preload("res://Scenes/objects/long_grass.tscn")

# define enum for the different plant types
enum PlantNodes { berry, carrot, flower, grass }

# counters for each instance of the plant nodes
#var berry_cnt: int = 0
#var carrot_cnt: int = 0
#var flower_cnt: int = 0
#var grass_cnt: int = 0

# -------------------------------
# Start and Update
# -------------------------------

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# example creation...
	# make a berry
	create_plant(
		PlantNodes.berry,
		Vector2(0, 20)
	)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:	
	# call to create when the player drags in the plants
	pass # UPDATE HERE


# --------------------------------
# Call to Create
# --------------------------------

# ** call to create plants HERE **
func create_plant(type: PlantNodes, spawn_position: Vector2) -> Plant:
	
	var plant_scene: PackedScene
	
	match type:
		PlantNodes.berry:
			plant_scene = berry_scene
		PlantNodes.carrot:
			plant_scene = carrot_scene
		PlantNodes.flower:
			plant_scene = flower_scene
		PlantNodes.grass:
			plant_scene = grass_scene

	# Create plant instance
	var plant_instance = plant_scene.instantiate() as Plant

	# Add to scene tree
	add_child(plant_instance)

	# Set position
	plant_instance.position = spawn_position

	return plant_instance
