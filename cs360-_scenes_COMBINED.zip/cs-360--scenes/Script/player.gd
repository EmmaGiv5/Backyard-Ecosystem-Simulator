extends CharacterBody2D

const SPEED = 90.0

var last_direction: Vector2 = Vector2.DOWN

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

func _physics_process(_delta: float) -> void:
	process_movement()
	process_animation()
	move_and_slide()

# ------------------------------
# Movement and Animation
# ------------------------------

func process_movement() -> void:
	var direction := Input.get_vector("left", "right", "up", "down")
	
	# check if player is moving or stopped
	if direction != Vector2.ZERO:
		# moving
		velocity = direction * SPEED
		last_direction = direction
	else:
		# stopped
		velocity = Vector2.ZERO

func process_animation() -> void:
	# if the player isn't moving, idle
	# if moving, run
	if velocity != Vector2.ZERO:
		play_animation("run", last_direction)
	else:
		play_animation("idle", last_direction)

func play_animation(prefix: String, dir: Vector2) -> void:
	# variable determines if the player is running or idle
	if dir.x != 0:
		animated_sprite_2d.flip_h = dir.x < 0
		animated_sprite_2d.play(prefix + "_right")
	#elif dir.x < 0:
		#animated_sprite_2d.flip_h = true
		#animated_sprite_2d.play("run_right")
	elif dir.y < 0:
		animated_sprite_2d.play(prefix + "_up")
	elif dir.y > 0:
		animated_sprite_2d.play(prefix + "_down")
