extends Node2D

# load global plant nodes
var berry_scene = load("res://Scenes/objects/berry.tscn")
var carrot_scene = load("res://Scenes/objects/carrot.tscn")
var flower_scene = load("res://Scenes/objects/flower.tscn")
var grass_scene = load("res://Scenes/objects/long_grass.tscn")

# define enum for the different plant types
enum PlantNodes { berry, carrot, flower, grass }

# counters for each instance of the plant nodes
#var berry_cnt: int = 0
#var carrot_cnt: int = 0
#var flower_cnt: int = 0
#var grass_cnt: int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# create berry
	create_plant(PlantNodes.berry)
	pass # START HERE

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:	
	# call to create when the player drags in the plants
	pass # UPDATE HERE


# --------------------------------
# Creation
# --------------------------------

func create_plant(type: PlantNodes) -> void:
	# ** create plants HERE **
	match type:
		PlantNodes.berry:
			# instance berry
			var berry_instance = berry_scene.instantiate()
			
			# add to current scene tree
			add_child(berry_instance)
			
			# set position
			berry_instance.position = Vector2(20, 0)
						
		PlantNodes.carrot:
			# instance carrot
			var carrot_instance = carrot_scene.instantiate()
			
			# add to current scene tree
			add_child(carrot_instance)
			
			# set position
			carrot_instance.position = Vector2(0, 20)
						
		PlantNodes.flower:
			# instance flower
			var flower_instance = flower_scene.instantiate()
			
			# add to current scene tree
			add_child(flower_instance)
			
			# set position
			flower_instance.position = Vector2(-20, 0)
						
		PlantNodes.grass:
			# instance grass
			var grass_instance = grass_scene.instantiate()
			
			# add to current scene tree
			add_child(grass_instance)
			
			# set position
			grass_instance.position = Vector2(0, -20)
			

# --------------------------------
# Phases
# 	healthy <--> wilted --> dead 
# --------------------------------

# plant moves forward in the phases 
func grow() -> void:
	#lifeState += 1
	pass

# plant moves back in the phases 
func wilt() -> void:
	#lifeState -= 1
	pass

# --------------------------------
# Calculations
# --------------------------------

# calculates the overall plant health 
func plant_health(lifeState) -> void:
	pass

# calcs sun level for plant's placement
func sun_level() -> void:
	pass

# calcs water level for plant's placement
func water_level() -> void:
	pass
