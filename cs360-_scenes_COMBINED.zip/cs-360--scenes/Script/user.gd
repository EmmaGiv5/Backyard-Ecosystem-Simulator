extends Node2D

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		print("Escape key pressed")
		get_tree().change_scene_to_file("res://Scenes/saved.tscn")


func _on_start_game_1_pressed() -> void:
	print("Game start")
	get_tree().change_scene_to_file("res://Scenes/backyard.tscn")
	#pass # Replace with function body.
